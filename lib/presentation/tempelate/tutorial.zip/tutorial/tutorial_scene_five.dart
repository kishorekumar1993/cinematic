import 'package:cinematic/model/screen_config.dart';
import 'package:flutter/material.dart';

class TutorialSceneFive extends StatefulWidget {
  final SceneConfig scene;
  final bool isPlaying;

  const TutorialSceneFive({
    super.key,
    required this.scene,
    required this.isPlaying,
  });

  @override
  State<TutorialSceneFive> createState() => _TutorialSceneFiveState();
}

class _TutorialSceneFiveState extends State<TutorialSceneFive>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: widget.scene.durationSeconds.clamp(3, 120)),
    );

    if (widget.isPlaying) {
      _controller.forward();
    }
  }

  @override
  void didUpdateWidget(covariant TutorialSceneFive oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.isPlaying != widget.isPlaying) {
      widget.isPlaying ? _controller.forward() : _controller.stop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _buildVisualSide(SceneConfig scene) {
    if (scene.localImageBytes != null) {
      return Image.memory(
        scene.localImageBytes!,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
      );
    }
    if (scene.imageUrl.isNotEmpty) {
      return Image.network(
        scene.imageUrl,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
      );
    }
    return Container(
      color: const Color(0xFFECEFF1),
      child: const Center(
        child: Icon(Icons.image_outlined, size: 100, color: Colors.blueGrey),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scene = widget.scene;

    return Container(
      color: Colors.white,
      child: Row(
        children: [
          // Left side: Visuals
          Expanded(
            flex: 1,
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                final scale = Tween<double>(begin: 1.1, end: 1.0).animate(
                  CurvedAnimation(
                    parent: _controller,
                    curve: Curves.easeOutCubic,
                  ),
                );
                return ClipRect(
                  child: Transform.scale(
                    scale: scale.value,
                    child: _buildVisualSide(scene),
                  ),
                );
              },
            ),
          ),
          // Right side: Content
          Expanded(
            flex: 1,
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                final fade = Tween<double>(begin: 0.0, end: 1.0).animate(
                  CurvedAnimation(
                    parent: _controller,
                    curve: const Interval(0.2, 0.8, curve: Curves.easeIn),
                  ),
                );
                return FadeTransition(
                  opacity: fade,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 60.0, vertical: 40.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          scene.title,
                          style: const TextStyle(
                            fontSize: 42,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF101828),
                            height: 1.2,
                          ),
                        ),
                        if (scene.subtitle.isNotEmpty) ...[
                          const SizedBox(height: 16),
                          Text(
                            scene.subtitle,
                            style: const TextStyle(
                              fontSize: 22,
                              color: Color(0xFF475467),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                        const SizedBox(height: 32),
                        if (scene.body.isNotEmpty)
                          Text(
                            scene.body,
                            style: const TextStyle(
                              fontSize: 18,
                              color: Color(0xFF344054),
                              height: 1.6,
                            ),
                          ),
                        const SizedBox(height: 32),
                        if (scene.keyPoints.isNotEmpty)
                          ...scene.keyPoints.map((kp) {
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 16.0),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Icon(Icons.check_circle, color: Color(0xFF12B76A), size: 24),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      kp,
                                      style: const TextStyle(
                                        fontSize: 16,
                                        color: Color(0xFF344054),
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          }),
                      ],
                    ),
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
