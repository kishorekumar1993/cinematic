import 'package:cinematic/model/screen_config.dart';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'dart:math' as Math;

class TutorialSceneOne extends StatefulWidget {
  final SceneConfig scene;
  final bool isPlaying;

  const TutorialSceneOne({
    super.key,
    required this.scene,
    required this.isPlaying,
  });

  @override
  State<TutorialSceneOne> createState() => _TutorialSceneOneState();
}

class _TutorialSceneOneState extends State<TutorialSceneOne>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fade;
  late Animation<Offset> _slide;
  late AnimationController _orbController;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: widget.scene.durationSeconds.clamp(3, 120)),
    );

    _fade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.1, 0.5, curve: Curves.easeIn),
      ),
    );

    _slide = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.1, 0.5, curve: Curves.easeOutBack),
      ),
    );

    _orbController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat(reverse: true);

    if (widget.isPlaying) {
      _controller.forward();
    }
  }

  @override
  void didUpdateWidget(covariant TutorialSceneOne oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.isPlaying != widget.isPlaying) {
      widget.isPlaying ? _controller.forward() : _controller.stop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _orbController.dispose();
    super.dispose();
  }

  Widget _background(SceneConfig scene) {
    if (scene.localImageBytes != null) {
      return Image.memory(
        scene.localImageBytes!,
        fit: BoxFit.cover,
      );
    }
    if (scene.imageUrl.isNotEmpty) {
      return Image.network(
        scene.imageUrl,
        fit: BoxFit.cover,
      );
    }
    return Container(color: Colors.black);
  }

  @override
  Widget build(BuildContext context) {
    final scene = widget.scene;

    return AnimatedBuilder(
      animation: Listenable.merge([_controller, _orbController]),
      builder: (context, child) {
        return Stack(
          fit: StackFit.expand,
          children: [
            _background(scene),
            // Dark Gradient Overlay
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.black87, Colors.transparent, Colors.black87],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
            // Floating Animated Orbs for Premium feel
            Positioned(
              left: 100 + 50 * Math.sin(_orbController.value * 2 * 3.14),
              top: 100 + 50 * Math.cos(_orbController.value * 2 * 3.14),
              child: Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.blueAccent.withValues(alpha: 0.2),
                  boxShadow: [
                    BoxShadow(color: Colors.blueAccent.withValues(alpha: 0.3), blurRadius: 100, spreadRadius: 50)
                  ],
                ),
              ),
            ),
            Positioned(
              right: 100 + 50 * Math.cos(_orbController.value * 2 * 3.14),
              bottom: 100 + 50 * Math.sin(_orbController.value * 2 * 3.14),
              child: Container(
                width: 350,
                height: 350,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.purpleAccent.withValues(alpha: 0.2),
                  boxShadow: [
                    BoxShadow(color: Colors.purpleAccent.withValues(alpha: 0.3), blurRadius: 100, spreadRadius: 50)
                  ],
                ),
              ),
            ),
            SafeArea(
              child: Center(
                child: FadeTransition(
                  opacity: _fade,
                  child: SlideTransition(
                    position: _slide,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 40.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(32),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                          child: Container(
                            padding: const EdgeInsets.all(48),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.05),
                              borderRadius: BorderRadius.circular(32),
                              border: Border.all(color: Colors.white.withValues(alpha: 0.2), width: 1.5),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.2),
                                  blurRadius: 30,
                                  spreadRadius: -5,
                                )
                              ],
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withValues(alpha: 0.1),
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                  child: const Text(
                                    "INTRODUCTION",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 3.0,
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 32),
                                Text(
                                  scene.title,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    fontSize: 56,
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white,
                                    height: 1.1,
                                    shadows: [
                                      Shadow(color: Colors.black45, blurRadius: 10, offset: Offset(0, 5))
                                    ]
                                  ),
                                ),
                                if (scene.subtitle.isNotEmpty) ...[
                                  const SizedBox(height: 20),
                                  Text(
                                    scene.subtitle,
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      fontSize: 22,
                                      color: Colors.white70,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ],
                                const SizedBox(height: 48),
                                if (scene.keyPoints.isNotEmpty)
                                  Wrap(
                                    spacing: 24,
                                    runSpacing: 24,
                                    alignment: WrapAlignment.center,
                                    children: List.generate(scene.keyPoints.length, (index) {
                                      return Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                                        decoration: BoxDecoration(
                                          color: Colors.black.withValues(alpha: 0.4),
                                          borderRadius: BorderRadius.circular(16),
                                          border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            CircleAvatar(
                                              backgroundColor: Colors.white,
                                              radius: 14,
                                              child: Text(
                                                "${index + 1}",
                                                style: const TextStyle(
                                                  color: Colors.black87,
                                                  fontWeight: FontWeight.w900,
                                                  fontSize: 14,
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 12),
                                            Text(
                                              scene.keyPoints[index],
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 16,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            )
                                          ],
                                        ),
                                      );
                                    }),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
