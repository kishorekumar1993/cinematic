// // lib/main.dart

// import 'package:cinematic/presentation/animatic_home.dart';
// import 'package:flutter/material.dart';

// void main() {
//   runApp(const CinematicApp());
// }

// class CinematicApp extends StatelessWidget {
//   const CinematicApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Cinematic Flutter Video Maker',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData.dark().copyWith(
//         scaffoldBackgroundColor: const Color(0xFF05070A),
//         colorScheme: ColorScheme.fromSeed(
//           seedColor: const Color(0xFF5B86FF),
//           brightness: Brightness.dark,
//         ),
//       ),
//       home: const AnimaticHomePage(),
//       // home: const AnimaticHomePage(),
//     );
//   }
// }


// lib/main.dart
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const CinematicApp());
}

class CinematicApp extends StatelessWidget {
  const CinematicApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cinematic Flutter Video Maker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF05070A),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF5B86FF),
          brightness: Brightness.dark,
        ),
      ),
      home: const AnimaticHomePage(),
    );
  }
}

/// ----------------------
/// MODELS (Animatic Archive)
/// ----------------------

class SceneConfig {
  final String id;
  final String title;
  final String subtitle;
  final String hook;
  final String body;
  final List<String> keyPoints;
  final String imageUrl;
  final int durationSeconds;
  final String effect;
  final String transitionOut;
  final String textEffect;
  final String voiceTone;
  final String musicStyle;
  final String animationInstructions;
  final String closureLine;

  /// Local uploaded image (not stored in JSON)
  final Uint8List? localImageBytes;
  final String? localImageName;

  /// LEFT side full details (for dual template)
  final String leftTitle;
  final String leftSubtitle;
  final String leftBody;
  final List<String> leftKeyPoints;
  final String leftImageUrl;

  /// RIGHT side full details (for dual template)
  final String rightTitle;
  final String rightSubtitle;
  final String rightBody;
  final List<String> rightKeyPoints;
  final String rightImageUrl;

  SceneConfig({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.hook,
    required this.body,
    required this.keyPoints,
    required this.imageUrl,
    required this.durationSeconds,
    required this.effect,
    required this.transitionOut,
    required this.textEffect,
    required this.voiceTone,
    required this.musicStyle,
    required this.animationInstructions,
    required this.closureLine,
    this.localImageBytes,
    this.localImageName,

    // dual left defaults
    this.leftTitle = '',
    this.leftSubtitle = '',
    this.leftBody = '',
    this.leftKeyPoints = const [],
    this.leftImageUrl = '',

    // dual right defaults
    this.rightTitle = '',
    this.rightSubtitle = '',
    this.rightBody = '',
    this.rightKeyPoints = const [],
    this.rightImageUrl = '',
  });

  factory SceneConfig.fromJson(Map<String, dynamic> json) {
    return SceneConfig(
      id: json['id'] as String,
      title: json['title'] as String? ?? '',
      subtitle: json['subtitle'] as String? ?? '',
      hook: json['hook'] as String? ?? '',
      body: json['body'] as String? ?? '',
      keyPoints: (json['keyPoints'] as List?)
              ?.map((e) => (e ?? '').toString())
              .toList() ??
          const [],
      imageUrl: json['imageUrl'] as String? ?? '',
      durationSeconds: json['durationSeconds'] as int? ?? 8,
      effect: json['effect'] as String? ?? 'zoom_in',
      transitionOut: json['transitionOut'] as String? ?? 'fade',
      textEffect: json['textEffect'] as String? ?? 'fade',
      voiceTone: json['voiceTone'] as String? ?? '',
      musicStyle: json['musicStyle'] as String? ?? '',
      animationInstructions: json['animationInstructions'] as String? ?? '',
      closureLine: json['closureLine'] as String? ?? '',
      localImageBytes: null,
      localImageName: null,

      // LEFT dual fields
      leftTitle: json['leftTitle'] as String? ?? '',
      leftSubtitle: json['leftSubtitle'] as String? ?? '',
      leftBody: json['leftBody'] as String? ?? '',
      leftKeyPoints: (json['leftKeyPoints'] as List?)
              ?.map((e) => (e ?? '').toString())
              .toList() ??
          const [],
      leftImageUrl: json['leftImageUrl'] as String? ?? '',

      // RIGHT dual fields
      rightTitle: json['rightTitle'] as String? ?? '',
      rightSubtitle: json['rightSubtitle'] as String? ?? '',
      rightBody: json['rightBody'] as String? ?? '',
      rightKeyPoints: (json['rightKeyPoints'] as List?)
              ?.map((e) => (e ?? '').toString())
              .toList() ??
          const [],
      rightImageUrl: json['rightImageUrl'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'subtitle': subtitle,
      'hook': hook,
      'body': body,
      'keyPoints': keyPoints,
      'imageUrl': imageUrl,
      'durationSeconds': durationSeconds,
      'effect': effect,
      'transitionOut': transitionOut,
      'textEffect': textEffect,
      'voiceTone': voiceTone,
      'musicStyle': musicStyle,
      'animationInstructions': animationInstructions,
      'closureLine': closureLine,

      // LEFT
      'leftTitle': leftTitle,
      'leftSubtitle': leftSubtitle,
      'leftBody': leftBody,
      'leftKeyPoints': leftKeyPoints,
      'leftImageUrl': leftImageUrl,

      // RIGHT
      'rightTitle': rightTitle,
      'rightSubtitle': rightSubtitle,
      'rightBody': rightBody,
      'rightKeyPoints': rightKeyPoints,
      'rightImageUrl': rightImageUrl,
      // localImageBytes/localImageName NOT serialized
    };
  }
}

class AnimaticArchive {
  final String version;
  final String title;
  final DateTime createdAt;
  final List<SceneConfig> scenes;

  AnimaticArchive({
    required this.version,
    required this.title,
    required this.createdAt,
    required this.scenes,
  });

  factory AnimaticArchive.fromJson(Map<String, dynamic> json) {
    return AnimaticArchive(
      version: json['version'] as String? ?? '1.0.0',
      title: json['title'] as String? ?? 'Untitled Animatic',
      createdAt: DateTime.parse(json['createdAt'] as String),
      scenes: (json['scenes'] as List<dynamic>)
          .map((e) => SceneConfig.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'version': version,
      'title': title,
      'createdAt': createdAt.toIso8601String(),
      'scenes': scenes.map((e) => e.toJson()).toList(),
    };
  }
}

/// Sample animatic archive JSON (you can change this to dual_category later)
const String sampleArchiveJson = '''
{
  "version": "1.0.0",
  "title": "Flutter Basics Cinematic",
  "createdAt": "2025-12-05T10:00:00.000Z",
  "scenes": [
    {
      "id": "scene1",
      "title": "What is Flutter?",
      "subtitle": "Modern UI toolkit by Google",
      "body": "Flutter lets you build beautiful native apps for mobile, web, and desktop from a single codebase.",
      "imageUrl": "https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg",
      "durationSeconds": 8,
      "effect": "zoom_in",
      "transitionOut": "fade",
      "textEffect": "fade"
    },
    {
      "id": "scene2",
      "title": "Why use Flutter?",
      "subtitle": "Speed and beauty",
      "body": "Hot reload, expressive UI, and rich widget library make development faster and more fun.",
      "imageUrl": "https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg",
      "durationSeconds": 8,
      "effect": "pan_right",
      "transitionOut": "fade",
      "textEffect": "slide_up"
    },
    {
      "id": "scene3",
      "title": "One Codebase",
      "subtitle": "Ship everywhere",
      "body": "Write once and deploy to Android, iOS, Web, Windows, macOS, and Linux.",
      "imageUrl": "https://images.pexels.com/photos/160107/pexels-photo-160107.jpeg",
      "durationSeconds": 10,
      "effect": "zoom_out",
      "transitionOut": "fade",
      "textEffect": "slide_left"
    }
  ]
}
''';

/// ----------------------
/// HOME PAGE
/// ----------------------

class AnimaticHomePage extends StatefulWidget {
  const AnimaticHomePage({super.key});

  @override
  State<AnimaticHomePage> createState() => _AnimaticHomePageState();
}

class _AnimaticHomePageState extends State<AnimaticHomePage> {
  AnimaticArchive? _archive;
  bool _isPlaying = true;

  int _currentSceneIndex = 0; // for info panel on the right

  @override
  void initState() {
    super.initState();
    _loadSampleArchive();
  }

  void _loadSampleArchive() {
    final map = jsonDecode(sampleArchiveJson) as Map<String, dynamic>;
    setState(() {
      _archive = AnimaticArchive.fromJson(map);
      _currentSceneIndex = 0;
    });
  }

  void _togglePlay() {
    setState(() {
      _isPlaying = !_isPlaying;
    });
  }

  void _openFullPreview() {
    if (_archive == null) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => FullPreviewPage(archive: _archive!),
      ),
    );
  }

  void _showArchiveJson() {
    if (_archive == null) return;

    final jsonStr =
        const JsonEncoder.withIndent('  ').convert(_archive!.toJson());

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF10121A),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.7,
          maxChildSize: 0.95,
          minChildSize: 0.4,
          expand: false,
          builder: (context, scrollController) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 50,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const Text(
                    'Animatic Archive JSON',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: SingleChildScrollView(
                      controller: scrollController,
                      child: SelectableText(
                        jsonStr,
                        style: const TextStyle(
                          fontFamily: 'monospace',
                          fontSize: 12,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showLoadJsonDialog() {
    final controller = TextEditingController(text: sampleArchiveJson);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF181B24),
        title: const Text('Paste Animatic Archive JSON'),
        content: SizedBox(
          width: 500,
          child: TextField(
            controller: controller,
            maxLines: 15,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: 'Paste JSON here',
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              try {
                final map =
                    jsonDecode(controller.text) as Map<String, dynamic>;
                final archive = AnimaticArchive.fromJson(map);
                setState(() {
                  _archive = archive;
                  _currentSceneIndex = 0;
                });
                Navigator.pop(context);
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Invalid JSON: $e')),
                );
              }
            },
            child: const Text('Load'),
          ),
        ],
      ),
    );
  }

  void _editScene(int index) async {
    if (_archive == null) return;
    final scene = _archive!.scenes[index];

    final updated = await showModalBottomSheet<SceneConfig>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF11131B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return SceneEditorSheet(scene: scene, isNew: false);
      },
    );

    if (updated != null) {
      setState(() {
        _archive!.scenes[index] = updated;
      });
    }
  }

  void _addScene() async {
    final now = DateTime.now().millisecondsSinceEpoch.toString();

    _archive ??= AnimaticArchive(
      version: '1.0.0',
      title: 'My Cinematic',
      createdAt: DateTime.now(),
      scenes: [],
    );

    final newScene = SceneConfig(
      id: 'scene_$now',
      title: 'New Scene',
      subtitle: 'Subtitle here',
      hook: '',
      body: '',
      keyPoints: const [],
      imageUrl:
          'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg',
      durationSeconds: 8,
      effect: 'zoom_in',
      transitionOut: 'fade',
      textEffect: 'fade',
      voiceTone: '',
      musicStyle: '',
      animationInstructions: '',
      closureLine: '',
    );

    final updated = await showModalBottomSheet<SceneConfig>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF11131B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return SceneEditorSheet(scene: newScene, isNew: true);
      },
    );

    if (updated != null) {
      setState(() {
        _archive!.scenes.add(updated);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final archive = _archive;

    return Scaffold(
      appBar: AppBar(
        title: Text(archive?.title ?? 'Cinematic Flutter Video Maker'),
        backgroundColor: Colors.black.withValues(alpha: 0.3),
        elevation: 0,
        actions: [
          IconButton(
            tooltip: 'Load JSON',
            onPressed: _showLoadJsonDialog,
            icon: const Icon(Icons.cloud_download),
          ),
          IconButton(
            tooltip: 'Show Archive JSON',
            onPressed: _showArchiveJson,
            icon: const Icon(Icons.code),
          ),
          IconButton(
            tooltip: 'Add Scene',
            onPressed: _addScene,
            icon: const Icon(Icons.add),
          ),
          IconButton(
            tooltip: 'Full Preview',
            onPressed: archive == null ? null : _openFullPreview,
            icon: const Icon(Icons.slideshow),
          ),
          IconButton(
            tooltip: _isPlaying ? 'Pause' : 'Play',
            onPressed: _togglePlay,
            icon: Icon(_isPlaying ? Icons.pause : Icons.play_arrow),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: archive == null
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: _showLoadJsonDialog,
                    icon: const Icon(Icons.cloud_download),
                    label: const Text('Load Animatic JSON'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _loadSampleArchive,
                    icon: const Icon(Icons.movie_creation_outlined),
                    label: const Text('Load Sample Flutter Cinematic'),
                  ),
                ],
              ),
            )
          : LayoutBuilder(
              builder: (context, constraints) {
                final isWide = constraints.maxWidth > 900;

                if (!isWide) {
                  final currentScene = archive.scenes[
                      _currentSceneIndex.clamp(0, archive.scenes.length - 1)];

                  return Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            gradient: const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Color(0xFF1E2240),
                                Color(0xFF090C18),
                              ],
                            ),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.08),
                            ),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.movie_filter_outlined, size: 32),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      archive.title,
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${archive.scenes.length} scenes • Tap a scene to edit',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.white
                                            .withValues(alpha: 0.7),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              FilledButton.tonalIcon(
                                onPressed: _openFullPreview,
                                icon: const Icon(Icons.fullscreen),
                                label: const Text('Preview'),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: OutlinedButton.icon(
                            onPressed: _showLoadJsonDialog,
                            icon: const Icon(Icons.cloud_upload_outlined),
                            label: const Text('Load JSON'),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        child: AspectRatio(
                          aspectRatio: 16 / 9,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(24),
                              gradient: const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Color(0x66141A33),
                                  Color(0x22090C18),
                                ],
                              ),
                              border: Border.all(
                                color: Colors.white.withValues(alpha: 0.12),
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.7),
                                  blurRadius: 24,
                                  offset: const Offset(0, 18),
                                ),
                              ],
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(24),
                              child: CinematicPlayer(
                                scenes: archive.scenes,
                                isPlaying: _isPlaying,
                                loop: true,
                                onSceneChanged: (i) {
                                  setState(() {
                                    _currentSceneIndex = i;
                                  });
                                },
                              ),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Current Scene: ${currentScene.title}',
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.white.withValues(alpha: 0.8),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0D0F16),
                          border: Border(
                            top: BorderSide(
                              color: Colors.white.withValues(alpha: 0.08),
                              width: 1,
                            ),
                          ),
                        ),
                        child: SizedBox(
                          height: 96,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, index) {
                              final scene = archive.scenes[index];
                              return GestureDetector(
                                onTap: () => _editScene(index),
                                child: SceneThumbnail(
                                  scene: scene,
                                  index: index,
                                  isActive: index == _currentSceneIndex,
                                ),
                              );
                            },
                            separatorBuilder: (_, __) =>
                                const SizedBox(width: 8),
                            itemCount: archive.scenes.length,
                          ),
                        ),
                      ),
                    ],
                  );
                }

                final currentScene = archive.scenes[
                    _currentSceneIndex.clamp(0, archive.scenes.length - 1)];

                return Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 260,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(18),
                                color: const Color(0xFF101320),
                                border: Border.all(
                                  color:
                                      Colors.white.withValues(alpha: 0.06),
                                ),
                              ),
                              child: Row(
                                children: [
                                  const Icon(Icons.timeline_rounded, size: 24),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Scenes Timeline',
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          '${archive.scenes.length} scenes configured',
                                          style: TextStyle(
                                            fontSize: 11,
                                            color: Colors.white
                                                .withValues(alpha: 0.7),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    onPressed: _showLoadJsonDialog,
                                    icon: const Icon(
                                      Icons.cloud_upload_outlined,
                                      size: 20,
                                    ),
                                    tooltip: 'Load JSON',
                                  ),
                                  IconButton(
                                    onPressed: _addScene,
                                    icon:
                                        const Icon(Icons.add_circle_outline),
                                    tooltip: 'Add Scene',
                                  )
                                ],
                              ),
                            ),
                            const SizedBox(height: 10),
                            Expanded(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(18),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF070913),
                                    border: Border.all(
                                      color: Colors.white
                                          .withValues(alpha: 0.06),
                                    ),
                                  ),
                                  child: ListView.separated(
                                    padding: const EdgeInsets.all(8),
                                    itemBuilder: (context, index) {
                                      final scene = archive.scenes[index];
                                      return GestureDetector(
                                        onTap: () => _editScene(index),
                                        child: SceneThumbnail(
                                          scene: scene,
                                          index: index,
                                          isActive:
                                              index == _currentSceneIndex,
                                        ),
                                      );
                                    },
                                    separatorBuilder: (_, __) =>
                                        const SizedBox(height: 8),
                                    itemCount: archive.scenes.length,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          children: [
                            Container(
                              padding:
                                  const EdgeInsets.fromLTRB(18, 12, 18, 12),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                gradient: const LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    Color(0xFF1E2240),
                                    Color(0xFF090C18),
                                  ],
                                ),
                                border: Border.all(
                                  color:
                                      Colors.white.withValues(alpha: 0.08),
                                ),
                              ),
                              child: Row(
                                children: [
                                  const Icon(Icons.movie_creation_outlined,
                                      size: 30),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          archive.title,
                                          style: const TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          'Preview your cinematic animatic with smooth Ken Burns motion & text effects.',
                                          style: TextStyle(
                                            fontSize: 11.5,
                                            color: Colors.white
                                                .withValues(alpha: 0.8),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  FilledButton.tonalIcon(
                                    onPressed: _openFullPreview,
                                    icon: const Icon(Icons.slideshow),
                                    label: const Text('Full Preview'),
                                  ),
                                  const SizedBox(width: 8),
                                  IconButton.filledTonal(
                                    onPressed: _togglePlay,
                                    icon: Icon(_isPlaying
                                        ? Icons.pause_rounded
                                        : Icons.play_arrow_rounded),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 12),
                            Expanded(
                              child: AspectRatio(
                                aspectRatio: 16 / 9,
                                child: DecoratedBox(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(26),
                                    gradient: const LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [
                                        Color(0x66141A33),
                                        Color(0x22090C18),
                                      ],
                                    ),
                                    border: Border.all(
                                      color: Colors.white
                                          .withValues(alpha: 0.12),
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black
                                            .withValues(alpha: 0.7),
                                        blurRadius: 26,
                                        offset: const Offset(0, 22),
                                      ),
                                    ],
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(26),
                                    child: CinematicPlayer(
                                      scenes: archive.scenes,
                                      isPlaying: _isPlaying,
                                      loop: true,
                                      onSceneChanged: (i) {
                                        setState(() {
                                          _currentSceneIndex = i;
                                        });
                                      },
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      SizedBox(
                        width: 260,
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: const Color(0xFF0C0F19),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.08),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Current Scene',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                currentScene.title,
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              if (currentScene.subtitle.isNotEmpty) ...[
                                const SizedBox(height: 4),
                                Text(
                                  currentScene.subtitle,
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.white
                                        .withValues(alpha: 0.7),
                                  ),
                                ),
                              ],
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Icon(Icons.timer_outlined,
                                      size: 18,
                                      color: Colors.white
                                          .withValues(alpha: 0.85)),
                                  const SizedBox(width: 6),
                                  Text(
                                    '${currentScene.durationSeconds}s • ${currentScene.effect.replaceAll('_', ' ')}',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.white
                                          .withValues(alpha: 0.8),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              if (currentScene.voiceTone.isNotEmpty ||
                                  currentScene.musicStyle.isNotEmpty)
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(14),
                                    color: Colors.white
                                        .withValues(alpha: 0.03),
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      if (currentScene.voiceTone.isNotEmpty)
                                        Text(
                                          'Voice: ${currentScene.voiceTone}',
                                          style: const TextStyle(
                                            fontSize: 11.5,
                                          ),
                                        ),
                                      if (currentScene.musicStyle.isNotEmpty)
                                        Text(
                                          'Music: ${currentScene.musicStyle}',
                                          style: const TextStyle(
                                            fontSize: 11.5,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              const SizedBox(height: 10),
                              if (currentScene.keyPoints.isNotEmpty) ...[
                                Text(
                                  'Key Points',
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white
                                        .withValues(alpha: 0.9),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Expanded(
                                  child: SingleChildScrollView(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: currentScene.keyPoints
                                          .map(
                                            (kp) => Padding(
                                              padding:
                                                  const EdgeInsets.only(
                                                      bottom: 2),
                                              child: Text(
                                                '• $kp',
                                                style: TextStyle(
                                                  fontSize: 11.5,
                                                  color: Colors.white
                                                      .withValues(alpha: 0.8),
                                                ),
                                              ),
                                            ),
                                          )
                                          .toList(),
                                    ),
                                  ),
                                ),
                              ] else
                                Expanded(
                                  child: Center(
                                    child: Text(
                                      'Add key points\nfor this scene in editor.',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 11.5,
                                        color: Colors.white
                                            .withValues(alpha: 0.6),
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}

/// ----------------------
/// FULL PREVIEW PAGE
/// ----------------------

class FullPreviewPage extends StatefulWidget {
  final AnimaticArchive archive;

  const FullPreviewPage({super.key, required this.archive});

  @override
  State<FullPreviewPage> createState() => _FullPreviewPageState();
}

class _FullPreviewPageState extends State<FullPreviewPage> {
  bool _isPlaying = true;
  int _currentIndex = 0;

  void _togglePlay() {
    setState(() {
      _isPlaying = !_isPlaying;
    });
  }

  @override
  Widget build(BuildContext context) {
    final scenes = widget.archive.scenes;

    return Scaffold(
      backgroundColor: const Color(0xFF000000),
      body: SafeArea(
        child: Center(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: _togglePlay,
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(0),
                child: CinematicPlayer(
                  scenes: scenes,
                  isPlaying: _isPlaying,
                  loop: true,
                  onSceneChanged: (i) {
                    setState(() {
                      _currentIndex = i;
                    });
                  },
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// ----------------------
/// CINEMATIC PLAYER
/// ----------------------

class CinematicPlayer extends StatefulWidget {
  final List<SceneConfig> scenes;
  final bool isPlaying;
  final bool loop;
  final ValueChanged<int>? onSceneChanged;

  const CinematicPlayer({
    super.key,
    required this.scenes,
    required this.isPlaying,
    this.loop = false,
    this.onSceneChanged,
  });

  @override
  State<CinematicPlayer> createState() => _CinematicPlayerState();
}

class _CinematicPlayerState extends State<CinematicPlayer> {
  int _currentIndex = 0;
  Timer? _timer;

  SceneConfig get _currentScene => widget.scenes[_currentIndex];

  @override
  void initState() {
    super.initState();
    _scheduleNext();
  }

  @override
  void didUpdateWidget(covariant CinematicPlayer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.isPlaying != widget.isPlaying) {
      if (widget.isPlaying) {
        _scheduleNext();
      } else {
        _timer?.cancel();
      }
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _notifySceneChanged() {
    widget.onSceneChanged?.call(_currentIndex);
  }

  void _scheduleNext() {
    _timer?.cancel();
    if (!widget.isPlaying || widget.scenes.isEmpty) return;

    final duration =
        Duration(seconds: _currentScene.durationSeconds.clamp(3, 120));

    _timer = Timer(duration, () {
      if (!mounted) return;

      setState(() {
        if (_currentIndex < widget.scenes.length - 1) {
          _currentIndex++;
        } else if (widget.loop) {
          _currentIndex = 0;
        }
      });

      _notifySceneChanged();
      _scheduleNext();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.scenes.isEmpty) {
      return const Center(child: Text('No scenes in archive'));
    }

    final scene = _currentScene;

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 800),
      switchInCurve: Curves.easeOut,
      switchOutCurve: Curves.easeIn,
      child: scene.effect == 'dual_category'
          ? DualCategoryScene(
              key: ValueKey('dual_${scene.id}'),
              scene: scene,
              isPlaying: widget.isPlaying,
            )
          : CinematicScene(
              key: ValueKey(scene.id),
              scene: scene,
              isPlaying: widget.isPlaying,
            ),
    );
  }
}

/// ----------------------
/// SINGLE CINEMATIC SCENE
/// ----------------------


class CinematicScene extends StatefulWidget {
  final SceneConfig scene;
  final bool isPlaying;

  const CinematicScene({
    super.key,
    required this.scene,
    required this.isPlaying,
  });

  @override
  State<CinematicScene> createState() => _CinematicSceneState();
}

class _CinematicSceneState extends State<CinematicScene>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<double> _zoom;
  late final Animation<Offset> _slide;

  bool _initialized = false;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: Duration(
        seconds: widget.scene.durationSeconds.clamp(5, 120),
      ),
    );

    _fade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );

    _zoom = Tween<double>(begin: 1.05, end: 1.02).animate(
      CurvedAnimation(parent: _controller, curve: Curves.linear),
    );

    _slide = Tween<Offset>(
      begin: const Offset(0, 0.18),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );

    _initialized = true;

    if (widget.isPlaying) {
      _controller.forward();
    }
  }

  @override
  void didUpdateWidget(covariant CinematicScene oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (!_initialized || !mounted) return;

    if (oldWidget.isPlaying != widget.isPlaying) {
      if (widget.isPlaying) {
        // restart safely
        if (_controller.status == AnimationStatus.dismissed ||
            _controller.status == AnimationStatus.completed) {
          _controller.forward(from: 0);
        } else if (!_controller.isAnimating) {
          _controller.forward();
        }
      } else {
        _controller.stop();
      }
    }
  }

  @override
  void dispose() {
    _initialized = false;
    _controller.dispose();
    super.dispose();
  }

  // -------------------------
  // BACKGROUND IMAGE – NULL SAFE
  // -------------------------
  Widget _buildBackground(SceneConfig scene) {
    final Uint8List? bytes = scene.localImageBytes;

    if (bytes != null) {
      return Image.memory(
        bytes,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _fallbackBackground(),
      );
    }

    if (scene.imageUrl.isNotEmpty) {
      return Image.network(
        scene.imageUrl,
        fit: BoxFit.cover,
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;
          return Container(
            color: Colors.black,
            alignment: Alignment.center,
            child: const CircularProgressIndicator(),
          );
        },
        errorBuilder: (_, __, ___) => _fallbackBackground(),
      );
    }

    return _fallbackBackground();
  }

  Widget _fallbackBackground() {
    return Container(
      color: Colors.black,
      alignment: Alignment.center,
      child: const Icon(
        Icons.newspaper_rounded,
        size: 48,
        color: Colors.white70,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scene = widget.scene;

    final bodyText = scene.body;
    final editionTitle = scene.subtitle.isEmpty
        ? 'SPECIAL EDITION'
        : scene.subtitle.toUpperCase();

    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        return Stack(
          fit: StackFit.expand,
          children: [
            // 1) Background: grayscale + darkened
            Transform.scale(
              scale: _zoom.value,
              child: ColorFiltered(
                colorFilter: const ColorFilter.matrix(<double>[
                  // grayscale
                  0.3, 0.3, 0.3, 0, 0,
                  0.3, 0.3, 0.3, 0, 0,
                  0.3, 0.3, 0.3, 0, 0,
                  0,   0,   0,   1, 0,
                ]),
                child: ColorFiltered(
                  colorFilter: ColorFilter.mode(
                    Colors.black.withOpacity(0.3),
                    BlendMode.darken,
                  ),
                  child: _buildBackground(scene),
                ),
              ),
            ),

            // 2) Vignette
            Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center,
                  radius: 1.1,
                  colors: [
                    Colors.black.withOpacity(0.0),
                    Colors.black.withOpacity(0.7),
                  ],
                  stops: const [0.4, 1.0],
                ),
              ),
            ),

            // 3) Top edition strip
            Positioned(
              top: 20,
              left: 0,
              right: 0,
              child: Center(
                child: FadeTransition(
                  opacity: _fade,
                  child: Text(
                    editionTitle,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.white70,
                      letterSpacing: 2,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),

            // 4) Main headline
            Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: const EdgeInsets.only(top: 56),
                child: FadeTransition(
                  opacity: _fade,
                  child: Text(
                    scene.title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      height: 1.15,
                      fontFamily: 'Georgia', // will fallback if not present
                    ),
                  ),
                ),
              ),
            ),

            // 5) Hook / tagline
            if (scene.hook.isNotEmpty)
              Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: const EdgeInsets.only(top: 104),
                  child: FadeTransition(
                    opacity: _fade,
                    child: Text(
                      scene.hook,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 15,
                        fontStyle: FontStyle.italic,
                        color: Colors.white70,
                      ),
                    ),
                  ),
                ),
              ),

            // 6) Bottom article
            FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(24, 20, 24, 56),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [
                          Colors.black.withOpacity(0.95),
                          Colors.black.withOpacity(0.6),
                          Colors.transparent,
                        ],
                      ),
                    ),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 900),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (bodyText.isNotEmpty)
                            Text(
                              bodyText,
                              style: const TextStyle(
                                fontSize: 16,
                                height: 1.5,
                                fontFamily: 'Times New Roman',
                                color: Colors.white,
                              ),
                            ),

                          if (scene.keyPoints.isNotEmpty) ...[
                            const SizedBox(height: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: scene.keyPoints
                                  .map(
                                    (kp) => Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 4),
                                      child: Text(
                                        '• $kp',
                                        style: const TextStyle(
                                          fontSize: 14,
                                          color: Colors.white70,
                                        ),
                                      ),
                                    ),
                                  )
                                  .toList(),
                            ),
                          ],

                          if (scene.closureLine.isNotEmpty) ...[
                            const SizedBox(height: 10),
                            const Divider(
                              color: Colors.white30,
                              height: 1,
                            ),
                            const SizedBox(height: 6),
                            Text(
                              scene.closureLine,
                              style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

/// ----------------------
/// DUAL CATEGORY SCENE
/// ----------------------

class DualCategoryScene extends StatefulWidget {
  final SceneConfig scene;
  final bool isPlaying;

  const DualCategoryScene({
    super.key,
    required this.scene,
    required this.isPlaying,
  });

  @override
  State<DualCategoryScene> createState() => _DualCategorySceneState();
}

class _DualCategorySceneState extends State<DualCategoryScene>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: widget.scene.durationSeconds.clamp(3, 120)),
    )..forward();

    _fade = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.1, 0.7, curve: Curves.easeOut),
    );

    _slide = Tween<Offset>(
      begin: const Offset(0.0, 0.25),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.15, 0.7, curve: Curves.easeOutCubic),
      ),
    );
  }

  @override
  void didUpdateWidget(covariant DualCategoryScene oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.isPlaying != widget.isPlaying) {
      if (widget.isPlaying) {
        _controller.forward();
      } else {
        _controller.stop();
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _glowCircle({required Color color, required double size}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color, Colors.transparent],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scene = widget.scene;
    final scheme = Theme.of(context).colorScheme;

    final leftBullets = scene.leftKeyPoints.map((e) => '• $e').join('\n');
    final rightBullets = scene.rightKeyPoints.map((e) => '• $e').join('\n');

    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        return Stack(
          fit: StackFit.expand,
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFF050712),
                    Color(0xFF05060A),
                  ],
                ),
              ),
            ),
            Positioned(
              top: -120,
              left: -40,
              child: _glowCircle(
                color: scheme.primary.withValues(alpha: 0.4),
                size: 220,
              ),
            ),
            Positioned(
              bottom: -120,
              right: -60,
              child: _glowCircle(
                color: Colors.pinkAccent.withValues(alpha: 0.35),
                size: 260,
              ),
            ),
            FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      if (scene.title.isNotEmpty) ...[
                        Text(
                          scene.title,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.2,
                          ),
                        ),
                        if (scene.subtitle.isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text(
                            scene.subtitle,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 13,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                        const SizedBox(height: 12),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(999),
                          child: LinearProgressIndicator(
                            value: _controller.value.clamp(0.0, 1.0),
                            minHeight: 4,
                            backgroundColor:
                                Colors.white.withValues(alpha: 0.08),
                            valueColor:
                                AlwaysStoppedAnimation(scheme.primary),
                          ),
                        ),
                        const SizedBox(height: 14),
                      ],
                      Expanded(
                        child: Row(
                          children: [
                            Expanded(
                              child: _DualSideCard(
                                label: 'LEFT',
                                title: scene.leftTitle,
                                subtitle: scene.leftSubtitle,
                                body: scene.leftBody,
                                bullets: leftBullets,
                                imageUrl: scene.leftImageUrl,
                                alignRight: false,
                              ),
                            ),
                            SizedBox(
                              width: 46,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: LinearGradient(
                                        colors: [
                                          scheme.primary,
                                          Colors.pinkAccent,
                                        ],
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: scheme.primary
                                              .withValues(alpha: 0.5),
                                          blurRadius: 16,
                                          offset: const Offset(0, 4),
                                        ),
                                      ],
                                    ),
                                    alignment: Alignment.center,
                                    child: const Text(
                                      'VS',
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: _DualSideCard(
                                label: 'RIGHT',
                                title: scene.rightTitle,
                                subtitle: scene.rightSubtitle,
                                body: scene.rightBody,
                                bullets: rightBullets,
                                imageUrl: scene.rightImageUrl,
                                alignRight: true,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (scene.closureLine.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Text(
                          scene.closureLine,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 14,
                            color: Colors.white70,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _DualSideCard extends StatelessWidget {
  final String label;
  final String title;
  final String subtitle;
  final String body;
  final String bullets;
  final String imageUrl;
  final bool alignRight;

  const _DualSideCard({
    required this.label,
    required this.title,
    required this.subtitle,
    required this.body,
    required this.bullets,
    required this.imageUrl,
    required this.alignRight,
  });

  @override
  Widget build(BuildContext context) {
    final textAlign = alignRight ? TextAlign.right : TextAlign.left;
    final scheme = Theme.of(context).colorScheme;

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withValues(alpha: 0.12),
            Colors.white.withValues(alpha: 0.02),
          ],
        ),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.18),
          width: 0.8,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.75),
            blurRadius: 20,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
            alignRight ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            child: imageUrl.isEmpty
                ? Container(
                    height: 150,
                    color: Colors.grey.shade900,
                    alignment: Alignment.center,
                    child: const Icon(Icons.image_not_supported,
                        color: Colors.white54),
                  )
                : Image.network(
                    imageUrl,
                    height: 150,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      height: 150,
                      color: Colors.grey.shade900,
                      alignment: Alignment.center,
                      child: const Icon(Icons.broken_image,
                          color: Colors.white54),
                    ),
                  ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
            child: Column(
              crossAxisAlignment: alignRight
                  ? CrossAxisAlignment.end
                  : CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: alignRight
                      ? MainAxisAlignment.end
                      : MainAxisAlignment.start,
                  children: [
                    if (!alignRight)
                      _labelChip(label: label, scheme: scheme),
                    Expanded(
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 6),
                        height: 1,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.white.withValues(alpha: 0.15),
                              Colors.transparent,
                            ],
                            begin: alignRight
                                ? Alignment.centerRight
                                : Alignment.centerLeft,
                            end: alignRight
                                ? Alignment.centerLeft
                                : Alignment.centerRight,
                          ),
                        ),
                      ),
                    ),
                    if (alignRight)
                      _labelChip(label: label, scheme: scheme),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  title.isEmpty ? ' ' : title,
                  textAlign: textAlign,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    height: 1.2,
                  ),
                ),
                if (subtitle.trim().isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    textAlign: textAlign,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.white70,
                    ),
                  ),
                ],
                if (body.trim().isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(
                    body,
                    textAlign: textAlign,
                    style: const TextStyle(
                      fontSize: 13.5,
                      color: Colors.white70,
                      height: 1.4,
                    ),
                  ),
                ],
                if (bullets.trim().isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(
                    bullets,
                    textAlign: textAlign,
                    style: const TextStyle(
                      fontSize: 13,
                      color: Colors.white70,
                      height: 1.4,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _labelChip({
    required String label,
    required ColorScheme scheme,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: scheme.primary.withValues(alpha: 0.18),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: scheme.primary.withValues(alpha: 0.5),
          width: 0.7,
        ),
      ),
      child: Text(
        label.toUpperCase(),
        style: const TextStyle(
          fontSize: 10,
          letterSpacing: 1.4,
          color: Colors.white,
        ),
      ),
    );
  }
}

/// ----------------------
/// SMALL THUMBNAIL
/// ----------------------

class SceneThumbnail extends StatelessWidget {
  final SceneConfig scene;
  final int index;
  final bool isActive;

  const SceneThumbnail({
    super.key,
    required this.scene,
    required this.index,
    this.isActive = false,
  });

  Widget _buildThumbImage(SceneConfig scene) {
    if (scene.localImageBytes != null) {
      return Image.memory(
        scene.localImageBytes!,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          color: Colors.grey.shade900,
          child: const Icon(Icons.image_not_supported),
        ),
      );
    }

    if (scene.imageUrl.isNotEmpty) {
      return Image.network(
        scene.imageUrl,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          color: Colors.grey.shade900,
          child: const Icon(Icons.image_not_supported),
        ),
      );
    }

    return Container(
      color: Colors.grey.shade900,
      child: const Icon(Icons.image_not_supported),
    );
  }

  @override
  Widget build(BuildContext context) {
    final borderColor = isActive
        ? Theme.of(context).colorScheme.primary
        : Colors.white.withValues(alpha: 0.15);

    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Stack(
        children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: Stack(
              fit: StackFit.expand,
              children: [
                _buildThumbImage(scene),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [
                        Colors.black.withValues(alpha: 0.7),
                        Colors.black.withValues(alpha: 0.0),
                      ],
                    ),
                    border: Border.all(color: borderColor, width: 1),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Align(
                    alignment: Alignment.bottomLeft,
                    child: Text(
                      '${index + 1}. ${scene.title}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 11,
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (isActive)
            Positioned(
              top: 6,
              right: 6,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.7),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: const Text(
                  'LIVE',
                  style: TextStyle(
                    fontSize: 9,
                    letterSpacing: 1,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// ----------------------
/// SCENE EDITOR BOTTOM SHEET (DUAL)
/// ----------------------

class SceneEditorSheet extends StatefulWidget {
  final SceneConfig scene;
  final bool isNew;

  const SceneEditorSheet({
    super.key,
    required this.scene,
    this.isNew = false,
  });

  @override
  State<SceneEditorSheet> createState() => _SceneEditorSheetState();
}

class _SceneEditorSheetState extends State<SceneEditorSheet> {
  // BASE
  late TextEditingController _titleCtrl;
  late TextEditingController _subtitleCtrl;
  late TextEditingController _hookCtrl;
  late TextEditingController _bodyCtrl;
  late TextEditingController _keyPointsCtrl;
  late TextEditingController _imageUrlCtrl;
  late TextEditingController _voiceToneCtrl;
  late TextEditingController _musicStyleCtrl;
  late TextEditingController _durationCtrl;
  late TextEditingController _animationInstructionsCtrl;
  late TextEditingController _closureLineCtrl;

  // NEW: LEFT
  late TextEditingController _leftTitleCtrl;
  late TextEditingController _leftSubtitleCtrl;
  late TextEditingController _leftBodyCtrl;
  late TextEditingController _leftKeyPointsCtrl;
  late TextEditingController _leftImageUrlCtrl;

  // NEW: RIGHT
  late TextEditingController _rightTitleCtrl;
  late TextEditingController _rightSubtitleCtrl;
  late TextEditingController _rightBodyCtrl;
  late TextEditingController _rightKeyPointsCtrl;
  late TextEditingController _rightImageUrlCtrl;

  late String _selectedEffect;
  late String _selectedTextEffect;
  late String _selectedTransition;

  final List<String> _effects = const [
    'zoom_in',
    'zoom_out',
    'pan_left',
    'pan_right',
    'dual_category', // dual template
  ];

  final List<String> _textEffects = const [
    'fade',
    'slide_up',
    'slide_left',
    'typewriter',
  ];

  final List<String> _transitions = const [
    'fade',
    'none',
  ];

  SceneConfig? _previewScene;
  Key _previewKey = UniqueKey();

  Uint8List? _localImageBytes;
  String? _localImageName;

  @override
  void initState() {
    super.initState();
    final s = widget.scene;

    // base
    _titleCtrl = TextEditingController(text: s.title);
    _subtitleCtrl = TextEditingController(text: s.subtitle);
    _hookCtrl = TextEditingController(text: s.hook);
    _bodyCtrl = TextEditingController(text: s.body);
    _keyPointsCtrl = TextEditingController(text: s.keyPoints.join('\n'));
    _imageUrlCtrl = TextEditingController(text: s.imageUrl);
    _voiceToneCtrl = TextEditingController(text: s.voiceTone);
    _musicStyleCtrl = TextEditingController(text: s.musicStyle);
    _durationCtrl = TextEditingController(text: s.durationSeconds.toString());
    _animationInstructionsCtrl =
        TextEditingController(text: s.animationInstructions);
    _closureLineCtrl = TextEditingController(text: s.closureLine);

    // left
    _leftTitleCtrl = TextEditingController(text: s.leftTitle);
    _leftSubtitleCtrl = TextEditingController(text: s.leftSubtitle);
    _leftBodyCtrl = TextEditingController(text: s.leftBody);
    _leftKeyPointsCtrl =
        TextEditingController(text: s.leftKeyPoints.join('\n'));
    _leftImageUrlCtrl = TextEditingController(text: s.leftImageUrl);

    // right
    _rightTitleCtrl = TextEditingController(text: s.rightTitle);
    _rightSubtitleCtrl = TextEditingController(text: s.rightSubtitle);
    _rightBodyCtrl = TextEditingController(text: s.rightBody);
    _rightKeyPointsCtrl =
        TextEditingController(text: s.rightKeyPoints.join('\n'));
    _rightImageUrlCtrl = TextEditingController(text: s.rightImageUrl);

    _selectedEffect = _effects.contains(s.effect) ? s.effect : 'zoom_in';
    _selectedTextEffect =
        _textEffects.contains(s.textEffect) ? s.textEffect : 'fade';
    _selectedTransition =
        _transitions.contains(s.transitionOut) ? s.transitionOut : 'fade';

    _localImageBytes = s.localImageBytes;
    _localImageName = s.localImageName;
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _subtitleCtrl.dispose();
    _hookCtrl.dispose();
    _bodyCtrl.dispose();
    _keyPointsCtrl.dispose();
    _imageUrlCtrl.dispose();
    _voiceToneCtrl.dispose();
    _musicStyleCtrl.dispose();
    _durationCtrl.dispose();
    _animationInstructionsCtrl.dispose();
    _closureLineCtrl.dispose();

    _leftTitleCtrl.dispose();
    _leftSubtitleCtrl.dispose();
    _leftBodyCtrl.dispose();
    _leftKeyPointsCtrl.dispose();
    _leftImageUrlCtrl.dispose();

    _rightTitleCtrl.dispose();
    _rightSubtitleCtrl.dispose();
    _rightBodyCtrl.dispose();
    _rightKeyPointsCtrl.dispose();
    _rightImageUrlCtrl.dispose();

    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.image,
        allowMultiple: false,
        withData: true,
      );

      if (result == null || result.files.isEmpty) {
        return;
      }

      final file = result.files.single;
      final Uint8List? safeBytes = file.bytes;

      if (safeBytes == null) {
        if (kDebugMode) {
          debugPrint(
              'Cannot read image bytes. bytes is null for file: ${file.name}');
        }
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Cannot read image bytes on this platform')),
        );
        return;
      }

      if (!mounted) return;
      setState(() {
        _localImageBytes = safeBytes;
        _localImageName = file.name;

        if (_imageUrlCtrl.text.trim().isEmpty) {
          _imageUrlCtrl.text = 'local://${file.name}';
        }

        _previewScene = _buildSceneFromInputs();
        _previewKey = UniqueKey();
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Selected: ${file.name}')),
      );
    } catch (e, st) {
      if (kDebugMode) {
        debugPrint('Error picking image: $e\n$st');
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error picking image: $e')),
      );
    }
  }

  SceneConfig _buildSceneFromInputs() {
    final duration = int.tryParse(_durationCtrl.text.trim()) ?? 8;

    final keyPoints = _keyPointsCtrl.text
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    final leftKeyPoints = _leftKeyPointsCtrl.text
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    final rightKeyPoints = _rightKeyPointsCtrl.text
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    return SceneConfig(
      id: widget.scene.id,
      title: _titleCtrl.text.trim(),
      subtitle: _subtitleCtrl.text.trim(),
      hook: _hookCtrl.text.trim(),
      body: _bodyCtrl.text.trim(),
      keyPoints: keyPoints,
      imageUrl: _imageUrlCtrl.text.trim(),
      durationSeconds: duration,
      effect: _selectedEffect,
      transitionOut: _selectedTransition,
      textEffect: _selectedTextEffect,
      voiceTone: _voiceToneCtrl.text.trim(),
      musicStyle: _musicStyleCtrl.text.trim(),
      animationInstructions: _animationInstructionsCtrl.text.trim(),
      closureLine: _closureLineCtrl.text.trim(),
      localImageBytes: _localImageBytes,
      localImageName: _localImageName,

      // LEFT
      leftTitle: _leftTitleCtrl.text.trim(),
      leftSubtitle: _leftSubtitleCtrl.text.trim(),
      leftBody: _leftBodyCtrl.text.trim(),
      leftKeyPoints: leftKeyPoints,
      leftImageUrl: _leftImageUrlCtrl.text.trim(),

      // RIGHT
      rightTitle: _rightTitleCtrl.text.trim(),
      rightSubtitle: _rightSubtitleCtrl.text.trim(),
      rightBody: _rightBodyCtrl.text.trim(),
      rightKeyPoints: rightKeyPoints,
      rightImageUrl: _rightImageUrlCtrl.text.trim(),
    );
  }

  Widget _field(
    String label,
    TextEditingController controller, {
    int maxLines = 1,
    TextInputType? keyboardType,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  Widget _dropdownField({
    required String label,
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: DropdownButtonFormField<String>(
        value: value,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        items: items
            .map(
              (e) => DropdownMenuItem(
                value: e,
                child: Text(e),
              ),
            )
            .toList(),
        onChanged: onChanged,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);
    final bottomInset = media.viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + bottomInset),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: media.size.height * 0.85,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 48,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Text(
                widget.isNew ? 'Add Scene' : 'Edit Scene',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Base Scene',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color:
                                Colors.white.withValues(alpha: 0.85),
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      _field('Title', _titleCtrl),
                      _field('Subtitle', _subtitleCtrl),
                      _field('Hook (optional)', _hookCtrl, maxLines: 2),
                      _field('Body', _bodyCtrl, maxLines: 4),
                      _field(
                        'Key Points (one per line)',
                        _keyPointsCtrl,
                        maxLines: 4,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: _field(
                              'Background Image URL',
                              _imageUrlCtrl,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Column(
                            children: [
                              IconButton(
                                onPressed: _pickImage,
                                tooltip: 'Upload Image',
                                icon: const Icon(Icons.upload_file),
                              ),
                              if (_localImageName != null)
                                SizedBox(
                                  width: 120,
                                  child: Text(
                                    'Selected:\n$_localImageName',
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.white
                                          .withValues(alpha: 0.7),
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      _dropdownField(
                        label: 'Image / Scene Effect',
                        value: _selectedEffect,
                        items: _effects,
                        onChanged: (v) {
                          if (v != null) {
                            setState(() => _selectedEffect = v);
                          }
                        },
                      ),
                      _dropdownField(
                        label: 'Text Effect',
                        value: _selectedTextEffect,
                        items: _textEffects,
                        onChanged: (v) {
                          if (v != null) {
                            setState(() => _selectedTextEffect = v);
                          }
                        },
                      ),
                      _dropdownField(
                        label: 'Transition Out',
                        value: _selectedTransition,
                        items: _transitions,
                        onChanged: (v) {
                          if (v != null) {
                            setState(() => _selectedTransition = v);
                          }
                        },
                      ),
                      _field('Voice Tone', _voiceToneCtrl),
                      _field('Music Style', _musicStyleCtrl),
                      _field(
                        'Duration (seconds)',
                        _durationCtrl,
                        keyboardType: TextInputType.number,
                      ),
                      _field(
                        'Animation Instructions',
                        _animationInstructionsCtrl,
                        maxLines: 3,
                      ),
                      _field(
                        'Closure Line (optional)',
                        _closureLineCtrl,
                        maxLines: 2,
                      ),
                      const SizedBox(height: 16),
                      Divider(color: Colors.white.withValues(alpha: 0.2)),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Dual Comparison (Left & Right)',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color:
                                Colors.white.withValues(alpha: 0.9),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'LEFT',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white
                                        .withValues(alpha: 0.8),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                _field('Left Title', _leftTitleCtrl),
                                _field('Left Subtitle', _leftSubtitleCtrl),
                                _field('Left Body', _leftBodyCtrl,
                                    maxLines: 3),
                                _field(
                                  'Left Key Points (one per line)',
                                  _leftKeyPointsCtrl,
                                  maxLines: 3,
                                ),
                                _field(
                                  'Left Image URL',
                                  _leftImageUrlCtrl,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'RIGHT',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white
                                        .withValues(alpha: 0.8),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                _field('Right Title', _rightTitleCtrl),
                                _field('Right Subtitle', _rightSubtitleCtrl),
                                _field('Right Body', _rightBodyCtrl,
                                    maxLines: 3),
                                _field(
                                  'Right Key Points (one per line)',
                                  _rightKeyPointsCtrl,
                                  maxLines: 3,
                                ),
                                _field(
                                  'Right Image URL',
                                  _rightImageUrlCtrl,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Tip: For comparison template, set Effect = dual_category.',
                          style: TextStyle(
                            fontSize: 11,
                            color:
                                Colors.white.withValues(alpha: 0.7),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Preview Scene',
                          style: TextStyle(
                            fontSize: 14,
                            color:
                                Colors.white.withValues(alpha: 0.8),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 200,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.12),
                            ),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: _previewScene == null
                                ? Center(
                                    child: Text(
                                      'Press "Preview" below to see this scene',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.white
                                            .withValues(alpha: 0.7),
                                      ),
                                    ),
                                  )
                                : (_previewScene!.effect ==
                                        'dual_category'
                                    ? DualCategoryScene(
                                        key: _previewKey,
                                        scene: _previewScene!,
                                        isPlaying: true,
                                      )
                                    : CinematicScene(
                                        key: _previewKey,
                                        scene: _previewScene!,
                                        isPlaying: true,
                                      )),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  OutlinedButton.icon(
                    onPressed: () {
                      setState(() {
                        _previewScene = _buildSceneFromInputs();
                        _previewKey = UniqueKey();
                      });
                    },
                    icon: const Icon(Icons.play_circle_outline),
                    label: const Text('Preview'),
                  ),
                  Row(
                    children: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Cancel'),
                      ),
                      const SizedBox(width: 8),
                      FilledButton(
                        onPressed: () {
                          final updated = _buildSceneFromInputs();
                          Navigator.pop(context, updated);
                        },
                        child: const Text('Save'),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
